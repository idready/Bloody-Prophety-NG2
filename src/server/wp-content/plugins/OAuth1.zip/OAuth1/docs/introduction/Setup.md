# Setup

Before you can connect to your site with OAuth, you'll need to get it set up.

Right now, you'll need to install the plugin [from GitHub](https://github.com/WP-API/OAuth1). Inside your plugin directory, clone the plugin down:

    git clone https://github.com/WP-API/OAuth1

Once you've done this, head to your WordPress dashboard and activate the plugin. You should see an "Applications" item appear under the users menu: this is where you manage OAuth clients.